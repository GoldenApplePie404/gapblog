# ST7789驱动库
"""
版权所有 (c) 2020, 2021 Russ Hughes
本文件包含了以下版权声明和许可通知所涵盖的作品，并遵循相同的许可条款：
MIT许可证 (MIT)
版权所有 (c) 2019 Ivan Belokobylskiy
特此向任何获得本软件副本及相关文档文件（“软件”）的人员免费授予权限，以无限制地处理本软件，包括但不限于使用、复制、修改、合并、发布、分发、再许可和/或出售软件副本的权利，并允许向其提供软件的人员这样做，但须遵守以下条件：
上述版权声明和本许可通知应包含在本软件的所有副本或大部分内容中。
本软件“按原样”提供，不附带任何形式的明示或暗示保证，包括但不限于适销性、特定用途适用性和不侵权的保证。在任何情况下，作者或版权持有人均不对因本软件或本软件的使用或其他交易而产生的任何索赔、损害或其他责任负责，无论是合同诉讼、侵权诉讼还是其他诉讼。
本驱动基于devbis的st7789py_mpy模块，来自https://github.com/devbis/st7789py_mpy。
本驱动增加了对以下功能的支持：
- 320x240、240x240和135x240像素显示屏
- 显示屏旋转
- 基于硬件的滚动
- 使用8位和16位宽位图字体绘制文本，字体高度为8的倍数。其中包括从经典pc BIOS文本模式字体派生的12个位图字体。
- 使用转换的TrueType字体绘制文本。
- 绘制转换的位图
"""
 
import time
from micropython import const
import ustruct as struct
 
# commands
ST7789_NOP = const(0x00)
ST7789_SWRESET = const(0x01)
ST7789_RDDID = const(0x04)
ST7789_RDDST = const(0x09)
 
ST7789_SLPIN = const(0x10)
ST7789_SLPOUT = const(0x11)
ST7789_PTLON = const(0x12)
ST7789_NORON = const(0x13)
 
ST7789_INVOFF = const(0x20)
ST7789_INVON = const(0x21)
ST7789_DISPOFF = const(0x28)
ST7789_DISPON = const(0x29)
ST7789_CASET = const(0x2A)
ST7789_RASET = const(0x2B)
ST7789_RAMWR = const(0x2C)
ST7789_RAMRD = const(0x2E)
 
ST7789_PTLAR = const(0x30)
ST7789_VSCRDEF = const(0x33)
ST7789_COLMOD = const(0x3A)
ST7789_MADCTL = const(0x36)
ST7789_VSCSAD = const(0x37)
 
ST7789_MADCTL_MY = const(0x80)
ST7789_MADCTL_MX = const(0x40)
ST7789_MADCTL_MV = const(0x20)
ST7789_MADCTL_ML = const(0x10)
ST7789_MADCTL_BGR = const(0x08)
ST7789_MADCTL_MH = const(0x04)
ST7789_MADCTL_RGB = const(0x00)
 
ST7789_RDID1 = const(0xDA)
ST7789_RDID2 = const(0xDB)
ST7789_RDID3 = const(0xDC)
ST7789_RDID4 = const(0xDD)
 
COLOR_MODE_65K = const(0x50)
COLOR_MODE_262K = const(0x60)
COLOR_MODE_12BIT = const(0x03)
COLOR_MODE_16BIT = const(0x05)
COLOR_MODE_18BIT = const(0x06)
COLOR_MODE_16M = const(0x07)
 
# Color definitions
BLACK = const(0x0000)
BLUE = const(0x001F)
RED = const(0xF800)
GREEN = const(0x07E0)
CYAN = const(0x07FF)
MAGENTA = const(0xF81F)
YELLOW = const(0xFFE0)
WHITE = const(0xFFFF)
 
_ENCODE_PIXEL = ">H"
_ENCODE_POS = ">HH"
_DECODE_PIXEL = ">BBB"
 
_BUFFER_SIZE = const(256)
 
_BIT7 = const(0x80)
_BIT6 = const(0x40)
_BIT5 = const(0x20)
_BIT4 = const(0x10)
_BIT3 = const(0x08)
_BIT2 = const(0x04)
_BIT1 = const(0x02)
_BIT0 = const(0x01)
 
# Rotation tables (width, height, xstart, ystart)[rotation % 4]
 
WIDTH_320 = [(240, 320,  0,  0),
             (320, 240,  0,  0),
             (240, 320,  0,  0),
             (320, 240,  0,  0)]
 
WIDTH_240 = [(240, 240,  0,  0),
             (240, 240,  0,  0),
             (240, 240,  0, 80),
             (240, 240, 80,  0)]
 
WIDTH_135 = [(135, 240, 52, 40),
             (240, 135, 40, 53),
             (135, 240, 53, 40),
             (240, 135, 40, 52)]
 
# MADCTL ROTATIONS[rotation % 4]
ROTATIONS = [0x00, 0x60, 0xc0, 0xa0]
 
 
def color565(red, green=0, blue=0):
    """
    将红色、绿色和蓝色值（0-255）转换为16位565编码。

    Args:
        red (int or tuple/list): 红色值（0-255）或者包含红绿蓝三个颜色值的元组/列表。
        green (int, optional): 绿色值（0-255）。默认为0。
        blue (int, optional): 蓝色值（0-255）。默认为0。
    Returns:
        int: 16位565编码的颜色值。
    Raises:
        TypeError: 如果输入的red不是整数也不是包含三个整数的元组/列表。
    """
    try:
        red, green, blue = red  # see if the first var is a tuple/list
    except TypeError:
        pass
    return (red & 0xf8) << 8 | (green & 0xfc) << 3 | blue >> 3
 
 
def _encode_pos(x, y):
    """将位置编码为字节"""
    return struct.pack(_ENCODE_POS, x, y)
 
 
def _encode_pixel(color):
    """将像素颜色编码为字节。"""
    return struct.pack(_ENCODE_PIXEL, color)
 
 
class ST7789():
    """
    ST7789 驱动类
    参数:
        spi (spi): spi 对象 **必需**
        width (int): 显示屏宽度 **必需**
        height (int): 显示屏高度 **必需**
        reset (pin): 复位引脚
        dc (pin): dc 引脚 **必需**
        cs (pin): cs 引脚
        backlight (pin): 背光引脚
        rotation (int): 显示屏旋转
            - 0-竖屏
            - 1-横屏
            - 2-倒置竖屏
            - 3-倒置横屏
    """
    def __init__(self, spi, width, height, reset=None, dc=None,
                 cs=None, backlight=None, rotation=0):
        """
        初始化显示
        """
        if height != 240 or width not in [320, 240, 135]:
            raise ValueError(
                "Unsupported display. 320x240, 240x240 and 135x240 are supported."
            )
 
        if dc is None:
            raise ValueError("dc pin is required.")
 
        self._display_width = self.width = width
        self._display_height = self.height = height
        self.xstart = 0
        self.ystart = 0
        self.spi = spi
        self.reset = reset
        self.dc = dc
        self.cs = cs
        self.backlight = backlight
        self._rotation = rotation % 4
 
        self.hard_reset()
        self.soft_reset()
        self.sleep_mode(False)
 
        self._set_color_mode(COLOR_MODE_65K | COLOR_MODE_16BIT)
        time.sleep_ms(50)
        self.rotation(self._rotation)
        self.inversion_mode(True)
        time.sleep_ms(10)
        self._write(ST7789_NORON)
        time.sleep_ms(10)
        if backlight is not None:
            backlight.value(1)
        self.fill(0)
        self._write(ST7789_DISPON)
        time.sleep_ms(500)
 
    def _write(self, command=None, data=None):
        """向设备写入SPI命令和数据"""
        if self.cs:
            self.cs.off()
 
        if command is not None:
            self.dc.off()
            self.spi.write(bytes([command]))
        if data is not None:
            self.dc.on()
            self.spi.write(data)
            if self.cs:
                self.cs.on()
 
    def hard_reset(self):
        """
        执行硬复位操作
        """
        if self.cs:
            self.cs.off()
        if self.reset:
            self.reset.on()
        time.sleep_ms(50)
        if self.reset:
            self.reset.off()
        time.sleep_ms(50)
        if self.reset:
            self.reset.on()
        time.sleep_ms(150)
        if self.cs:
            self.cs.on()
 
    def soft_reset(self):
        """
        软复位显示屏
        """
        self._write(ST7789_SWRESET)
        time.sleep_ms(150)
 
    def sleep_mode(self, value):
        """
        启用或禁用显示屏休眠模式。
        Args:
            value (bool): 如果为True，则启用休眠模式；如果为False，则禁用休眠模式
        """
        if value:
            self._write(ST7789_SLPIN)
        else:
            self._write(ST7789_SLPOUT)
 
    def inversion_mode(self, value):
        """
        启用或禁用显示反转模式。
        Args:
            value (bool): 如果为True，则启用反转模式；如果为False，则禁用反转模式
        """
        if value:
            self._write(ST7789_INVON)
        else:
            self._write(ST7789_INVOFF)
 
    def _set_color_mode(self, mode):
        """
        设置显示颜色模式。
        Args:
            mode (int): 颜色模式
                COLOR_MODE_65K, COLOR_MODE_262K, COLOR_MODE_12BIT,
                COLOR_MODE_16BIT, COLOR_MODE_18BIT, COLOR_MODE_16M  
        Returns:
            None
        """

        self._write(ST7789_COLMOD, bytes([mode & 0x77]))
 
    def rotation(self, rotation):
        """
        设置显示旋转。
        Args:
            rotation (int):
                旋转模式：
                - 0: 竖屏
                - 1: 横屏
                - 2: 竖屏倒转
                - 3: 横屏倒转
        
        Raises:
            ValueError: 如果显示宽度不支持，抛出 ValueError 异常。
        """
        rotation %= 4
        self._rotation = rotation
        madctl = ROTATIONS[rotation]
 
        if self._display_width == 320:
            table = WIDTH_320
        elif self._display_width == 240:
            table = WIDTH_240
        elif self._display_width == 135:
            table = WIDTH_135
        else:
            raise ValueError(
                "Unsupported display. 320x240, 240x240 and 135x240 are supported."
            )
 
        self.width, self.height, self.xstart, self.ystart = table[rotation]
        self._write(ST7789_MADCTL, bytes([madctl]))
 
    def _set_columns(self, start, end):
        """
        向显示器发送CASET（列地址设置）命令。
        Args:
            start (int): 列起始地址
            end (int): 列结束地址
        Returns:
            None
        """

        if start <= end <= self.width:
            self._write(ST7789_CASET, _encode_pos(
                start+self.xstart, end + self.xstart))
 
    def _set_rows(self, start, end):
        """
        设置行地址范围。
        Args:
            start (int): 起始行地址
            end (int): 结束行地址  
        Returns:
            None
 
        """

        if start <= end <= self.height:
            self._write(ST7789_RASET, _encode_pos(
                start+self.ystart, end+self.ystart))
 
    def _set_window(self, x0, y0, x1, y1):
        """
        设置窗口到列和行地址。
        Args:
            x0 (int): 列起始地址
            y0 (int): 行起始地址
            x1 (int): 列结束地址
            y1 (int): 行结束地址
        """
        self._set_columns(x0, x1)
        self._set_rows(y0, y1)
        self._write(ST7789_RAMWR)
 
    def vline(self, x, y, length, color):
        """
        在指定位置和颜色绘制垂直线。
        Args:
            x (int): x坐标
            y (int): y坐标
            length (int): 线长
            color (int): 565编码的颜色
        """
        self.fill_rect(x, y, 1, length, color)
 
    def hline(self, x, y, length, color):
        """
        在给定的位置和颜色绘制水平线。
        Args:
            x (int): x坐标
            y (int): y坐标
            length (int): 线的长度
            color (int): 565编码的颜色  
        """
        self.fill_rect(x, y, length, 1, color)
 
    def pixel(self, x, y, color):
        """
        在给定的位置绘制一个像素点，并设置其颜色。
        Args:
            x (int): x 坐标
            y (int): y 坐标
            color (int): 565 编码的颜色值
        """
        self._set_window(x, y, x, y)
        self._write(None, _encode_pixel(color))
 
    def blit_buffer(self, buffer, x, y, width, height):
        """
        将缓冲区内容复制到指定位置进行显示。
        Args:
            buffer (bytes): 要复制到显示区域的数据
            x (int): 左上角 x 坐标
            y (int): 左上角 y 坐标
            width (int): 宽度
            height (int): 高度
        """
        self._set_window(x, y, x + width - 1, y + height - 1)
        self._write(None, buffer)
 
    def rect(self, x, y, w, h, color):
        """
        在指定位置、大小和颜色绘制一个矩形。
        
        Args:
            x (int): 矩形左上角的x坐标
            y (int): 矩形左上角的y坐标
            width (int): 矩形的宽度（像素）
            height (int): 矩形的高度（像素）
            color (int): 565编码的颜色
        
        """
        self.hline(x, y, w, color)
        self.vline(x, y, h, color)
        self.vline(x + w - 1, y, h, color)
        self.hline(x, y + h - 1, w, color)
 
    def fill_rect(self, x, y, width, height, color):
        """
        在给定的位置绘制一个填充了颜色的矩形。
        
        Args:
            x (int): 矩形左上角的 x 坐标
            y (int): 矩形左上角的 y 坐标
            width (int): 矩形的宽度（以像素为单位）
            height (int): 矩形的高度（以像素为单位）
            color (int): 565 编码的颜色值
        """
        self._set_window(x, y, x + width - 1, y + height - 1)
        chunks, rest = divmod(width * height, _BUFFER_SIZE)
        pixel = _encode_pixel(color)
        self.dc.on()
        if chunks:
            data = pixel * _BUFFER_SIZE
            for _ in range(chunks):
                self._write(None, data)
        if rest:
            self._write(None, pixel * rest)
 
    def fill(self, color):
        """
        用指定颜色填充整个FrameBuffer。
        
        Args:
            color (int): 565编码的颜色值
        """
        self.fill_rect(0, 0, self.width, self.height, color)
 
    def line(self, x0, y0, x1, y1, color):
        """
        绘制一条从点 (x0, y0) 到点 (x1, y1) 的单像素宽直线。
    
        Args:
            x0 (int): 起点 x 坐标
            y0 (int): 起点 y 坐标
            x1 (int): 终点 x 坐标
            y1 (int): 终点 y 坐标
            color (int): 565编码颜色
        """
        # 判断直线是否陡峭，即斜率是否大于1
        steep = abs(y1 - y0) > abs(x1 - x0)
        if steep:
            # 如果直线陡峭，则交换x0, y0和x1, y1的值
            x0, y0 = y0, x0
            x1, y1 = y1, x1
        # 确保x0小于等于x1，如果x0大于x1，则交换x0, x1和y0, y1的值
        if x0 > x1:
            x0, x1 = x1, x0
            y0, y1 = y1, y0
        # 计算x方向上的增量
        dx = x1 - x0
        # 计算y方向上的绝对增量
        dy = abs(y1 - y0)
        # 初始化误差项
        err = dx // 2
        # 根据y0和y1的关系确定ystep的值
        ystep = 1 if y0 < y1 else -1
        # 遍历x0到x1，绘制直线
        while x0 <= x1:
            if steep:
                # 如果直线陡峭，则调用pixel方法绘制像素点
                self.pixel(y0, x0, color)
            else:
                # 如果直线不陡峭，则调用pixel方法绘制像素点
                self.pixel(x0, y0, color)
            # 更新误差项
            err -= dy
            # 如果误差项小于0，则更新y0的值，并更新误差项
            if err < 0:
                y0 += ystep
                err += dx
            # 更新x0的值，继续绘制下一个像素点
            x0 += 1
 
    def vscrdef(self, tfa, vsa, bfa):
        """
        设置垂直滚动定义。
        
        为了在135x240显示屏上滚动，这些值应为40, 240, 40。
        显示区域上方有40行不可见行，随后是240行可见行，最后是40行不可见行。
        您可以在这些不可见区域中写入数据，并通过更改TFA、VSA和BFA值将其滚动到可见区域。
        
        Args:
            tfa (int): 顶部固定区域
            vsa (int): 垂直滚动区域
            bfa (int): 底部固定区域
        """
        struct.pack(">HHH", tfa, vsa, bfa)
        self._write(ST7789_VSCRDEF, struct.pack(">HHH", tfa, vsa, bfa))
 
    def vscsad(self, vssa):
        """
        设置RAM的垂直滚动起始地址。  
        定义在帧存储器中，哪一行将被写入作为显示中顶部固定区域最后一行之后的第一行。
        Args:
            vssa (int): 垂直滚动起始地址
        示例：
            for line in range(40, 280, 1):
                tft.vscsad(line)
                utime.sleep(0.01)
        """
        self._write(ST7789_VSCSAD, struct.pack(">H", vssa))
 
    def _text8(self, font, text, x0, y0, color=WHITE, background=BLACK):
        """
        内部方法，用于绘制宽度为8、高度为8或16的字符。
        
        Args:
            font (module): 要使用的字体模块
            text (str): 要绘制的文本
            x0 (int): 开始绘制的列位置
            y0 (int): 开始绘制的行位置
            color (int): 用于字符的565编码颜色
            background (int): 用于背景的565编码颜色
        """
        for char in text:
            ch = ord(char)
            if (font.FIRST <= ch < font.LAST
                    and x0+font.WIDTH <= self.width
                    and y0+font.HEIGHT <= self.height):
 
                if font.HEIGHT == 8:
                    passes = 1
                    size = 8
                    each = 0
                else:
                    passes = 2
                    size = 16
                    each = 8
 
                for line in range(passes):
                    idx = (ch-font.FIRST)*size+(each*line)
                    buffer = struct.pack(
                        '>64H',
                        color if font.FONT[idx] & _BIT7 else background,
                        color if font.FONT[idx] & _BIT6 else background,
                        color if font.FONT[idx] & _BIT5 else background,
                        color if font.FONT[idx] & _BIT4 else background,
                        color if font.FONT[idx] & _BIT3 else background,
                        color if font.FONT[idx] & _BIT2 else background,
                        color if font.FONT[idx] & _BIT1 else background,
                        color if font.FONT[idx] & _BIT0 else background,
                        color if font.FONT[idx+1] & _BIT7 else background,
                        color if font.FONT[idx+1] & _BIT6 else background,
                        color if font.FONT[idx+1] & _BIT5 else background,
                        color if font.FONT[idx+1] & _BIT4 else background,
                        color if font.FONT[idx+1] & _BIT3 else background,
                        color if font.FONT[idx+1] & _BIT2 else background,
                        color if font.FONT[idx+1] & _BIT1 else background,
                        color if font.FONT[idx+1] & _BIT0 else background,
                        color if font.FONT[idx+2] & _BIT7 else background,
                        color if font.FONT[idx+2] & _BIT6 else background,
                        color if font.FONT[idx+2] & _BIT5 else background,
                        color if font.FONT[idx+2] & _BIT4 else background,
                        color if font.FONT[idx+2] & _BIT3 else background,
                        color if font.FONT[idx+2] & _BIT2 else background,
                        color if font.FONT[idx+2] & _BIT1 else background,
                        color if font.FONT[idx+2] & _BIT0 else background,
                        color if font.FONT[idx+3] & _BIT7 else background,
                        color if font.FONT[idx+3] & _BIT6 else background,
                        color if font.FONT[idx+3] & _BIT5 else background,
                        color if font.FONT[idx+3] & _BIT4 else background,
                        color if font.FONT[idx+3] & _BIT3 else background,
                        color if font.FONT[idx+3] & _BIT2 else background,
                        color if font.FONT[idx+3] & _BIT1 else background,
                        color if font.FONT[idx+3] & _BIT0 else background,
                        color if font.FONT[idx+4] & _BIT7 else background,
                        color if font.FONT[idx+4] & _BIT6 else background,
                        color if font.FONT[idx+4] & _BIT5 else background,
                        color if font.FONT[idx+4] & _BIT4 else background,
                        color if font.FONT[idx+4] & _BIT3 else background,
                        color if font.FONT[idx+4] & _BIT2 else background,
                        color if font.FONT[idx+4] & _BIT1 else background,
                        color if font.FONT[idx+4] & _BIT0 else background,
                        color if font.FONT[idx+5] & _BIT7 else background,
                        color if font.FONT[idx+5] & _BIT6 else background,
                        color if font.FONT[idx+5] & _BIT5 else background,
                        color if font.FONT[idx+5] & _BIT4 else background,
                        color if font.FONT[idx+5] & _BIT3 else background,
                        color if font.FONT[idx+5] & _BIT2 else background,
                        color if font.FONT[idx+5] & _BIT1 else background,
                        color if font.FONT[idx+5] & _BIT0 else background,
                        color if font.FONT[idx+6] & _BIT7 else background,
                        color if font.FONT[idx+6] & _BIT6 else background,
                        color if font.FONT[idx+6] & _BIT5 else background,
                        color if font.FONT[idx+6] & _BIT4 else background,
                        color if font.FONT[idx+6] & _BIT3 else background,
                        color if font.FONT[idx+6] & _BIT2 else background,
                        color if font.FONT[idx+6] & _BIT1 else background,
                        color if font.FONT[idx+6] & _BIT0 else background,
                        color if font.FONT[idx+7] & _BIT7 else background,
                        color if font.FONT[idx+7] & _BIT6 else background,
                        color if font.FONT[idx+7] & _BIT5 else background,
                        color if font.FONT[idx+7] & _BIT4 else background,
                        color if font.FONT[idx+7] & _BIT3 else background,
                        color if font.FONT[idx+7] & _BIT2 else background,
                        color if font.FONT[idx+7] & _BIT1 else background,
                        color if font.FONT[idx+7] & _BIT0 else background
                    )
                    self.blit_buffer(buffer, x0, y0+8*line, 8, 8)
 
                x0 += 8
 
    def _text16(self, font, text, x0, y0, color=WHITE, background=BLACK):
        """
        绘制宽度为16、高度为16或32的字符的内部方法。
        
        Args:
            font (module): 要使用的字体模块
            text (str): 要绘制的文本
            x0 (int): 开始绘制的列
            y0 (int): 开始绘制的行
            color (int): 用于字符的565编码颜色
            background (int): 用于背景的565编码颜色
        Returns:
            无返回值
        
        """
        for char in text:
            ch = ord(char)
            if (font.FIRST <= ch < font.LAST
                    and x0+font.WIDTH <= self.width
                    and y0+font.HEIGHT <= self.height):
 
                each = 16
                if font.HEIGHT == 16:
                    passes = 2
                    size = 32
                else:
                    passes = 4
                    size = 64
 
                for line in range(passes):
                    idx = (ch-font.FIRST)*size+(each*line)
                    buffer = struct.pack(
                        '>128H',
                        color if font.FONT[idx] & _BIT7 else background,
                        color if font.FONT[idx] & _BIT6 else background,
                        color if font.FONT[idx] & _BIT5 else background,
                        color if font.FONT[idx] & _BIT4 else background,
                        color if font.FONT[idx] & _BIT3 else background,
                        color if font.FONT[idx] & _BIT2 else background,
                        color if font.FONT[idx] & _BIT1 else background,
                        color if font.FONT[idx] & _BIT0 else background,
                        color if font.FONT[idx+1] & _BIT7 else background,
                        color if font.FONT[idx+1] & _BIT6 else background,
                        color if font.FONT[idx+1] & _BIT5 else background,
                        color if font.FONT[idx+1] & _BIT4 else background,
                        color if font.FONT[idx+1] & _BIT3 else background,
                        color if font.FONT[idx+1] & _BIT2 else background,
                        color if font.FONT[idx+1] & _BIT1 else background,
                        color if font.FONT[idx+1] & _BIT0 else background,
                        color if font.FONT[idx+2] & _BIT7 else background,
                        color if font.FONT[idx+2] & _BIT6 else background,
                        color if font.FONT[idx+2] & _BIT5 else background,
                        color if font.FONT[idx+2] & _BIT4 else background,
                        color if font.FONT[idx+2] & _BIT3 else background,
                        color if font.FONT[idx+2] & _BIT2 else background,
                        color if font.FONT[idx+2] & _BIT1 else background,
                        color if font.FONT[idx+2] & _BIT0 else background,
                        color if font.FONT[idx+3] & _BIT7 else background,
                        color if font.FONT[idx+3] & _BIT6 else background,
                        color if font.FONT[idx+3] & _BIT5 else background,
                        color if font.FONT[idx+3] & _BIT4 else background,
                        color if font.FONT[idx+3] & _BIT3 else background,
                        color if font.FONT[idx+3] & _BIT2 else background,
                        color if font.FONT[idx+3] & _BIT1 else background,
                        color if font.FONT[idx+3] & _BIT0 else background,
                        color if font.FONT[idx+4] & _BIT7 else background,
                        color if font.FONT[idx+4] & _BIT6 else background,
                        color if font.FONT[idx+4] & _BIT5 else background,
                        color if font.FONT[idx+4] & _BIT4 else background,
                        color if font.FONT[idx+4] & _BIT3 else background,
                        color if font.FONT[idx+4] & _BIT2 else background,
                        color if font.FONT[idx+4] & _BIT1 else background,
                        color if font.FONT[idx+4] & _BIT0 else background,
                        color if font.FONT[idx+5] & _BIT7 else background,
                        color if font.FONT[idx+5] & _BIT6 else background,
                        color if font.FONT[idx+5] & _BIT5 else background,
                        color if font.FONT[idx+5] & _BIT4 else background,
                        color if font.FONT[idx+5] & _BIT3 else background,
                        color if font.FONT[idx+5] & _BIT2 else background,
                        color if font.FONT[idx+5] & _BIT1 else background,
                        color if font.FONT[idx+5] & _BIT0 else background,
                        color if font.FONT[idx+6] & _BIT7 else background,
                        color if font.FONT[idx+6] & _BIT6 else background,
                        color if font.FONT[idx+6] & _BIT5 else background,
                        color if font.FONT[idx+6] & _BIT4 else background,
                        color if font.FONT[idx+6] & _BIT3 else background,
                        color if font.FONT[idx+6] & _BIT2 else background,
                        color if font.FONT[idx+6] & _BIT1 else background,
                        color if font.FONT[idx+6] & _BIT0 else background,
                        color if font.FONT[idx+7] & _BIT7 else background,
                        color if font.FONT[idx+7] & _BIT6 else background,
                        color if font.FONT[idx+7] & _BIT5 else background,
                        color if font.FONT[idx+7] & _BIT4 else background,
                        color if font.FONT[idx+7] & _BIT3 else background,
                        color if font.FONT[idx+7] & _BIT2 else background,
                        color if font.FONT[idx+7] & _BIT1 else background,
                        color if font.FONT[idx+7] & _BIT0 else background,
                        color if font.FONT[idx+8] & _BIT7 else background,
                        color if font.FONT[idx+8] & _BIT6 else background,
                        color if font.FONT[idx+8] & _BIT5 else background,
                        color if font.FONT[idx+8] & _BIT4 else background,
                        color if font.FONT[idx+8] & _BIT3 else background,
                        color if font.FONT[idx+8] & _BIT2 else background,
                        color if font.FONT[idx+8] & _BIT1 else background,
                        color if font.FONT[idx+8] & _BIT0 else background,
                        color if font.FONT[idx+9] & _BIT7 else background,
                        color if font.FONT[idx+9] & _BIT6 else background,
                        color if font.FONT[idx+9] & _BIT5 else background,
                        color if font.FONT[idx+9] & _BIT4 else background,
                        color if font.FONT[idx+9] & _BIT3 else background,
                        color if font.FONT[idx+9] & _BIT2 else background,
                        color if font.FONT[idx+9] & _BIT1 else background,
                        color if font.FONT[idx+9] & _BIT0 else background,
                        color if font.FONT[idx+10] & _BIT7 else background,
                        color if font.FONT[idx+10] & _BIT6 else background,
                        color if font.FONT[idx+10] & _BIT5 else background,
                        color if font.FONT[idx+10] & _BIT4 else background,
                        color if font.FONT[idx+10] & _BIT3 else background,
                        color if font.FONT[idx+10] & _BIT2 else background,
                        color if font.FONT[idx+10] & _BIT1 else background,
                        color if font.FONT[idx+10] & _BIT0 else background,
                        color if font.FONT[idx+11] & _BIT7 else background,
                        color if font.FONT[idx+11] & _BIT6 else background,
                        color if font.FONT[idx+11] & _BIT5 else background,
                        color if font.FONT[idx+11] & _BIT4 else background,
                        color if font.FONT[idx+11] & _BIT3 else background,
                        color if font.FONT[idx+11] & _BIT2 else background,
                        color if font.FONT[idx+11] & _BIT1 else background,
                        color if font.FONT[idx+11] & _BIT0 else background,
                        color if font.FONT[idx+12] & _BIT7 else background,
                        color if font.FONT[idx+12] & _BIT6 else background,
                        color if font.FONT[idx+12] & _BIT5 else background,
                        color if font.FONT[idx+12] & _BIT4 else background,
                        color if font.FONT[idx+12] & _BIT3 else background,
                        color if font.FONT[idx+12] & _BIT2 else background,
                        color if font.FONT[idx+12] & _BIT1 else background,
                        color if font.FONT[idx+12] & _BIT0 else background,
                        color if font.FONT[idx+13] & _BIT7 else background,
                        color if font.FONT[idx+13] & _BIT6 else background,
                        color if font.FONT[idx+13] & _BIT5 else background,
                        color if font.FONT[idx+13] & _BIT4 else background,
                        color if font.FONT[idx+13] & _BIT3 else background,
                        color if font.FONT[idx+13] & _BIT2 else background,
                        color if font.FONT[idx+13] & _BIT1 else background,
                        color if font.FONT[idx+13] & _BIT0 else background,
                        color if font.FONT[idx+14] & _BIT7 else background,
                        color if font.FONT[idx+14] & _BIT6 else background,
                        color if font.FONT[idx+14] & _BIT5 else background,
                        color if font.FONT[idx+14] & _BIT4 else background,
                        color if font.FONT[idx+14] & _BIT3 else background,
                        color if font.FONT[idx+14] & _BIT2 else background,
                        color if font.FONT[idx+14] & _BIT1 else background,
                        color if font.FONT[idx+14] & _BIT0 else background,
                        color if font.FONT[idx+15] & _BIT7 else background,
                        color if font.FONT[idx+15] & _BIT6 else background,
                        color if font.FONT[idx+15] & _BIT5 else background,
                        color if font.FONT[idx+15] & _BIT4 else background,
                        color if font.FONT[idx+15] & _BIT3 else background,
                        color if font.FONT[idx+15] & _BIT2 else background,
                        color if font.FONT[idx+15] & _BIT1 else background,
                        color if font.FONT[idx+15] & _BIT0 else background
                    )
                    self.blit_buffer(buffer, x0, y0+8*line, 16, 8)
            x0 += font.WIDTH
 
    def text(self, font, text, x0, y0, color=WHITE, background=BLACK):
        """
        在指定字体和颜色下在显示器上绘制文本。支持8位和16位宽的字体。
        
        Args:
            font (module): 要使用的字体模块。
            text (str): 要绘制的文本
            x0 (int): 开始绘制的列位置
            y0 (int): 开始绘制的行位置
            color (int): 用于字符的565编码颜色
            background (int): 用于背景的565编码颜色
        """
        if font.WIDTH == 8:
            self._text8(font, text, x0, y0, color, background)
        else:
            self._text16(font, text, x0, y0, color, background)
 
    def bitmap(self, bitmap, x, y, index=0):
        """
        在显示屏上的指定列和行绘制位图
        
        Args:
            bitmap (bitmap_module): 包含要绘制的位图的模块
            x (int): 开始绘制的列
            y (int): 开始绘制的行
            index (int): 可选参数，从多个位图模块中绘制位图的索引
        
        """
        bitmap_size = bitmap.HEIGHT * bitmap.WIDTH
        buffer_len = bitmap_size * 2
        buffer = bytearray(buffer_len)
        bs_bit = bitmap.BPP * bitmap_size * index if index > 0 else 0
 
        for i in range(0, buffer_len, 2):
            color_index = 0
            for _ in range(bitmap.BPP):
                color_index <<= 1
                color_index |= (bitmap.BITMAP[bs_bit // 8]
                                & 1 << (7 - (bs_bit % 8))) > 0
                bs_bit += 1
 
            color = bitmap.PALETTE[color_index]
            buffer[i] = color & 0xff00 >> 8
            buffer[i + 1] = color_index & 0xff
 
        to_col = x + bitmap.WIDTH - 1
        to_row = y + bitmap.HEIGHT - 1
        if self.width > to_col and self.height > to_row:
            self._set_window(x, y, to_col, to_row)
            self._write(None, buffer)
 
    # @micropython.native
    def write(self, font, string, x, y, fg=WHITE, bg=BLACK):
        """
        在指定的列和行位置使用转换后的TrueType字体在显示器上写入字符串
        
        Args:
            font (font): 包含转换后的TrueType字体的模块
            string (str): 要写入的字符串
            x (int): 开始写入的列
            y (int): 开始写入的行
            fg (int): 前景色，可选，默认为WHITE
            bg (int): 背景色，可选，默认为BLACK
        
        """
        buffer_len = font.HEIGHT * font.MAX_WIDTH * 2
        buffer = bytearray(buffer_len)
        fg_hi = (fg & 0xff00) >> 8
        fg_lo = fg & 0xff
 
        bg_hi = (bg & 0xff00) >> 8
        bg_lo = bg & 0xff
 
        for character in string:
            try:
                char_index = font.MAP.index(character)
                offset = char_index * font.OFFSET_WIDTH
                bs_bit = font.OFFSETS[offset]
                if font.OFFSET_WIDTH > 1:
                    bs_bit = (bs_bit << 8) + font.OFFSETS[offset + 1]
 
                if font.OFFSET_WIDTH > 2:
                    bs_bit = (bs_bit << 8) + font.OFFSETS[offset + 2]
 
                char_width = font.WIDTHS[char_index]
                buffer_needed = char_width * font.HEIGHT * 2
 
                for i in range(0, buffer_needed, 2):
                    if font.BITMAPS[bs_bit // 8] & 1 << (7 - (bs_bit % 8)) > 0:
                        buffer[i] = fg_hi
                        buffer[i + 1] = fg_lo
                    else:
                        buffer[i] = bg_hi
                        buffer[i + 1] = bg_lo
 
                    bs_bit += 1
 
                to_col = x + char_width - 1
                to_row = y + font.HEIGHT - 1
                if self.width > to_col and self.height > to_row:
                    self._set_window(x, y, to_col, to_row)
                    self._write(None, buffer[:buffer_needed])
 
                x += char_width
 
            except ValueError:
                pass
 
    def write_width(self, font, string):
        """
        计算并返回使用指定字体绘制字符串时的像素宽度
        
        Args:
            font (font): 包含转换后的TrueType字体的模块
            string (str): 要测量的字符串
        Returns:
            int: 字符串的宽度（以像素为单位）
        """
        width = 0
        for character in string:
            try:
                char_index = font.MAP.index(character)
                width += font.WIDTHS[char_index]
 
            except ValueError:
                pass
 
        return width
