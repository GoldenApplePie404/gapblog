# 示例主程序
import time
from machine import Pin, SoftSPI
import st7789 as st7789
import vga2_bold_16x32 as font

def main1():
    # 创建SoftSPI对象(SCK对应SCL，MOSI对应SDA)
    spi = SoftSPI(baudrate=60000000, polarity=1, phase=0, sck=Pin(18), mosi=Pin(23), miso=Pin(19))

    # 创建ST7789对象
    tft = st7789.ST7789(
        spi,
        240,
        240,
        #（reset就是RST）
        reset=Pin(15, Pin.OUT),
        dc=Pin(2, Pin.OUT),
        cs=Pin(4, Pin.OUT),
        backlight=Pin(21, Pin.OUT),
        rotation=0)

    '''定义颜色'''

    red = st7789.color565(255, 0, 0)
    blue = st7789.color565(0, 0, 255)
    white = st7789.color565(255, 255, 255)
    blue_background = st7789.color565(0, 255, 128) 

    # 清屏
    # 清除屏幕内容
    tft.fill(0)


    # 在屏幕上显示"hello world"，颜色为红色
    tft.text(font, "Hello World", 30, 50, red)
    time.sleep(1)  # 等待1秒

    # 再次清除屏幕内容
    tft.fill(0)


    tft.text(font, "A TFT1.3 Screen", 0, 50, blue)
    time.sleep(1) 


    # 清除屏幕内容，并设置背景色为蓝色
    tft.fill(blue_background)
    time.sleep(1)
    
    tft.fill(0)
    white = st7789.color565(255, 255, 255)
    time.sleep(1)

main1()
