function pathfinding:options/diagonal/true
function pathfinding:options
