kill @e[tag=pathfinding]
