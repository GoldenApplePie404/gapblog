function pathfinding:options/visual/true
function pathfinding:options
