# Reset variables
data merge storage pathfinding:variables {stop_processing: 0b}
data merge storage pathfinding:variables {stop_tick: 0b}

# Unload math module
function math_pathfinding:uninstall

# Remove all scores
scoreboard objectives remove x_value 
scoreboard objectives remove z_value 
scoreboard objectives remove cost 
scoreboard objectives remove new_cost 
scoreboard objectives remove h_cost 
scoreboard objectives remove f_cost
scoreboard objectives remove left_side 
scoreboard objectives remove right_side 
scoreboard objectives remove multi
scoreboard objectives remove -1
scoreboard objectives remove max_steps 
scoreboard objectives remove total_steps
scoreboard objectives remove steps_per_tick 
scoreboard objectives remove tick_steps 
scoreboard objectives remove finder 
