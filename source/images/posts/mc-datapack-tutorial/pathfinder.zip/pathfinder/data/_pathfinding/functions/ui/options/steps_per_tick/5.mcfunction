function pathfinding:options/steps_per_tick/5
function pathfinding:options
