function pathfinding:options/algorithm/dijkstra
function pathfinding:options
