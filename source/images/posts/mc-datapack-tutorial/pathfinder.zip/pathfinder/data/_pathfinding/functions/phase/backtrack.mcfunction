# Set the path tag to current explore entity 
tag @e[tag=pathfinding,tag=explore,tag=current] add path

# Set the next_current tag to the next explore entity in the path
execute at @e[tag=pathfinding,tag=current,tag=explore,tag=pos_x] positioned ~1 ~ ~ as @e[tag=pathfinding,tag=explore,distance=..0.1] run tag @s add next_current
execute at @e[tag=pathfinding,tag=current,tag=explore,tag=neg_x] positioned ~-1 ~ ~ as @e[tag=pathfinding,tag=explore,distance=..0.1] run tag @s add next_current
execute at @e[tag=pathfinding,tag=current,tag=explore,tag=pos_z] positioned ~ ~ ~1 as @e[tag=pathfinding,tag=explore,distance=..0.1] run tag @s add next_current
execute at @e[tag=pathfinding,tag=current,tag=explore,tag=neg_z] positioned ~ ~ ~-1 as @e[tag=pathfinding,tag=explore,distance=..0.1] run tag @s add next_current
execute at @e[tag=pathfinding,tag=current,tag=explore,tag=pos_x_pos_z] positioned ~1 ~ ~1 as @e[tag=pathfinding,tag=explore,distance=..0.1] run tag @s add next_current
execute at @e[tag=pathfinding,tag=current,tag=explore,tag=neg_x_neg_z] positioned ~-1 ~ ~-1 as @e[tag=pathfinding,tag=explore,distance=..0.1] run tag @s add next_current
execute at @e[tag=pathfinding,tag=current,tag=explore,tag=pos_x_neg_z] positioned ~1 ~ ~-1 as @e[tag=pathfinding,tag=explore,distance=..0.1] run tag @s add next_current
execute at @e[tag=pathfinding,tag=current,tag=explore,tag=neg_x_pos_z] positioned ~-1 ~ ~1 as @e[tag=pathfinding,tag=explore,distance=..0.1] run tag @s add next_current

# Set the current tag to next_current
tag @e[tag=pathfinding,tag=current] remove current
tag @e[tag=pathfinding,tag=next_current] add current
tag @e[tag=pathfinding,tag=next_current] remove next_current

# Count steps and check if step count is too high (tick)
execute at @e[tag=pathfinding,tag=current] unless entity @e[tag=pathfinding,tag=start,distance=..0.1] unless data storage pathfinding:options {steps_per_tick: -1} run scoreboard players add @e[tag=pathfinding,tag=start] tick_steps 1
execute unless data storage pathfinding:options {steps_per_tick: -1} if score @e[tag=pathfinding,tag=start,limit=1] tick_steps >= @e[tag=pathfinding,tag=start,limit=1] steps_per_tick run data merge storage pathfinding:variables {stop_tick: 1b}
execute if data storage pathfinding:variables {stop_tick: 1b} run data merge storage pathfinding:variables {continue_at: "backtrack"}

# Restart if not at end
execute as @e[tag=pathfinding,tag=current] at @s if entity @e[tag=pathfinding,tag=start,distance=..0.1] run tag @s add path
execute at @e[tag=pathfinding,tag=current] unless entity @e[tag=pathfinding,tag=start,distance=..0.1] unless data storage pathfinding:variables {stop_tick: 1b} run function _pathfinding:phase/backtrack

# Start next phase if at end (and steps_per_tick is not -1)
execute unless data storage pathfinding:options {steps_per_tick: -1} at @e[tag=pathfinding,tag=current] if entity @e[tag=pathfinding,tag=start,distance=..0.1] if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:clear/explore
execute unless data storage pathfinding:options {steps_per_tick: -1} at @e[tag=pathfinding,tag=current] if entity @e[tag=pathfinding,tag=start,distance=..0.1] if data storage pathfinding:variables {stop_processing: 0b} if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:phase/build