data merge storage pathfinding:variables {stop_tick: 0b}
scoreboard players set @e[tag=pathfinding,tag=start] tick_steps 0

execute if data storage pathfinding:variables {continue_at: "explore"} run function _pathfinding:phase/explore
execute if data storage pathfinding:variables {continue_at: "backtrack"} run function _pathfinding:phase/backtrack
execute if data storage pathfinding:variables {continue_at: "build"} run function _pathfinding:phase/build