function pathfinding:options/visual/false
function pathfinding:options
