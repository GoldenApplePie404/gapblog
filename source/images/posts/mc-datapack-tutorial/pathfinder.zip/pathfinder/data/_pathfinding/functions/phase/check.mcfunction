scoreboard objectives add x dummy

# Check if there is exactly one start marker
execute store result score @s x if entity @e[tag=pathfinding,tag=start]
execute if score @s x matches 2.. run tellraw @s ["",{"text":"出错了！\n","color":"dark_red","bold": true},{"text":"只能存在1个起始点!","color":"red"}]
execute if score @s x matches 2.. run data merge storage pathfinding:variables {stop_processing: 1b}
execute if score @s x matches 0 run tellraw @s ["",{"text":"出错了！\n","color":"dark_red","bold": true},{"text":"未设置起始点!","color":"red"}]
execute if score @s x matches 0 run data merge storage pathfinding:variables {stop_processing: 1b}

# Check if there is exactly one end marker
execute store result score @s x if entity @e[tag=pathfinding,tag=end]
execute if score @s x matches 2.. run tellraw @s ["",{"text":"出错了！\n","color":"dark_red","bold": true},{"text":"只能存在1个终止点!","color":"red"}]
execute if score @s x matches 2.. run data merge storage pathfinding:variables {stop_processing: 1b}
execute if score @s x matches 0 run tellraw @s ["",{"text":"出错了！\n","color":"dark_red","bold": true},{"text":"未设置终止点!","color":"red"}]
execute if score @s x matches 0 run data merge storage pathfinding:variables {stop_processing: 1b}

scoreboard objectives remove x