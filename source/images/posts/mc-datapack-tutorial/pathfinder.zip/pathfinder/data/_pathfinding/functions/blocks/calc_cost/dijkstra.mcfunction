# Set new_cost of new armor stands
execute as @e[tag=pathfinding,tag=new] run scoreboard players set @s cost 999999999
execute as @e[tag=pathfinding,tag=new] run tag @s add modify
execute as @e[tag=pathfinding,tag=modify] run scoreboard players operation @s new_cost = @e[tag=pathfinding,tag=current,limit=1] cost
execute as @e[tag=pathfinding,tag=modify,tag=straight] run scoreboard players add @s new_cost 100
execute as @e[tag=pathfinding,tag=modify,tag=diagonal] run scoreboard players add @s new_cost 141