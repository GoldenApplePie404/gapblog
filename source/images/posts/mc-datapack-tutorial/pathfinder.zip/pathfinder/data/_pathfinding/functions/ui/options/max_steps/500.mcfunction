function pathfinding:options/max_steps/500
function pathfinding:options
