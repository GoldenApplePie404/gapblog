function pathfinding:options/max_steps/no_limit
function pathfinding:options
