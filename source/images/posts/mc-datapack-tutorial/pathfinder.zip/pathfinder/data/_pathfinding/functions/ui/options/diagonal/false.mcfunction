function pathfinding:options/diagonal/false
function pathfinding:options
