function pathfinding:options/welcome_message/true
function pathfinding:options
