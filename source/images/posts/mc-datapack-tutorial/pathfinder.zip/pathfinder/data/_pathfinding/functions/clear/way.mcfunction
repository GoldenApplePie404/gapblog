kill @e[tag=pathfinding,tag=waypoint]
