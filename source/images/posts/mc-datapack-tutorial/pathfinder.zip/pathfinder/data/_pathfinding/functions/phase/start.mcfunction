# Set maxCommandChainLength to max
gamerule maxCommandChainLength 2147483647

# Create all scores
scoreboard objectives add x_value dummy
scoreboard objectives add z_value dummy
scoreboard objectives add cost dummy
scoreboard objectives add new_cost dummy
scoreboard objectives add h_cost dummy
scoreboard objectives add f_cost dummy
scoreboard objectives add left_side dummy
scoreboard objectives add right_side dummy
scoreboard objectives add multi dummy
scoreboard objectives add -1 dummy
scoreboard objectives add max_steps dummy
scoreboard objectives add total_steps dummy
scoreboard objectives add steps_per_tick dummy
scoreboard objectives add tick_steps dummy
scoreboard objectives add finder dummy

# Load math module
function math_pathfinding:setup

# Set -1, multi and steps scores to start marker
scoreboard players set @e[tag=pathfinding,tag=start] multi 100
scoreboard players set @e[tag=pathfinding,tag=start] -1 -1
scoreboard players set @e[tag=pathfinding,tag=start] total_steps 0
scoreboard players set @e[tag=pathfinding,tag=start] tick_steps 0

# Set finder score to whoever called the function
scoreboard players set @s finder 1

# Message
tellraw @s {"text":"正在寻路中...","color": "yellow","italic": true}

# Load max_step and steps_per_tick options in score
execute store result score @e[tag=pathfinding,tag=start] max_steps run data get storage pathfinding:options max_steps
execute store result score @e[tag=pathfinding,tag=start] steps_per_tick run data get storage pathfinding:options steps_per_tick

# Summon first explore entity
execute if data storage pathfinding:options {visual: 0b} at @e[tag=pathfinding,tag=start] run summon minecraft:area_effect_cloud ~ ~ ~ {Tags: ["pathfinding", "explore", "current"],Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute if data storage pathfinding:options {visual: 1b} at @e[tag=pathfinding,tag=start] run summon minecraft:armor_stand ~ ~ ~ {Tags: ["pathfinding", "explore", "current"], NoGravity: 1b, Invulerable:1b}

# Set cost of first explore object to 0
scoreboard players set @e[tag=pathfinding,tag=current] cost 0

# Set x_value and z_value scores of start and end
execute as @e[tag=pathfinding,tag=start] store result score @s x_value run data get entity @s Pos[0]
execute as @e[tag=pathfinding,tag=start] store result score @s z_value run data get entity @s Pos[2]
execute as @e[tag=pathfinding,tag=end] store result score @s x_value run data get entity @s Pos[0]
execute as @e[tag=pathfinding,tag=end] store result score @s z_value run data get entity @s Pos[2]
