function pathfinding:options/welcome_message/false
function pathfinding:options
