function pathfinding:options/algorithm/a_star_euclidean
function pathfinding:options
