# Computing
execute if data storage pathfinding:variables {stop_tick: 1b} run function _pathfinding:continue

# Movement for follower: 
# Step 4
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_4] at @s run tp @s ~-0.25 ~ ~-0.25 135 5
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_4] at @s run tp @s ~0.25 ~ ~-0.25 -135 5
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_4] at @s run tp @s ~0.25 ~ ~0.25 -45 5
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_4] at @s run tp @s ~-0.25 ~ ~0.25 45 5

execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_4] run tag @s remove moving
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_4] run tag @s remove moving
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_4] run tag @s remove moving
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_4] run tag @s remove moving
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_4] run tag @s remove neg_x_neg_z_4
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_4] run tag @s remove pos_x_neg_z_4
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_4] run tag @s remove pos_x_pos_z_4
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_4] run tag @s remove neg_x_pos_z_4

# Step 3
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_3] at @s run tp @s ~-0.25 ~ ~-0.25 135 5
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_3] at @s run tp @s ~0.25 ~ ~-0.25 -135 5
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_3] at @s run tp @s ~0.25 ~ ~0.25 -45 5
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_3] at @s run tp @s ~-0.25 ~ ~0.25 45 5

execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_3] run tag @s add neg_x_neg_z_4
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_3] run tag @s add pos_x_neg_z_4
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_3] run tag @s add pos_x_pos_z_4
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_3] run tag @s add neg_x_pos_z_4
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_3] run tag @s remove neg_x_neg_z_3
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_3] run tag @s remove pos_x_neg_z_3
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_3] run tag @s remove pos_x_pos_z_3
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_3] run tag @s remove neg_x_pos_z_3

# Step 2
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_2] at @s run tp @s ~-0.25 ~ ~-0.25 135 5
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_2] at @s run tp @s ~0.25 ~ ~-0.25 -135 5
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_2] at @s run tp @s ~0.25 ~ ~0.25 -45 5
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_2] at @s run tp @s ~-0.25 ~ ~0.25 45 5

execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_2] run tag @s add neg_x_neg_z_3
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_2] run tag @s add pos_x_neg_z_3
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_2] run tag @s add pos_x_pos_z_3
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_2] run tag @s add neg_x_pos_z_3
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_2] run tag @s remove neg_x_neg_z_2
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_2] run tag @s remove pos_x_neg_z_2
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_2] run tag @s remove pos_x_pos_z_2
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_2] run tag @s remove neg_x_pos_z_2

# Step 1
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_1] at @s run tp @s ~-0.25 ~ ~-0.25 135 5
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_1] at @s run tp @s ~0.25 ~ ~-0.25 -135 5
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_1] at @s run tp @s ~0.25 ~ ~0.25 -45 5
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_1] at @s run tp @s ~-0.25 ~ ~0.25 45 5

execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_1] run tag @s add neg_x_neg_z_2
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_1] run tag @s add pos_x_neg_z_2
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_1] run tag @s add pos_x_pos_z_2
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_1] run tag @s add neg_x_pos_z_2
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_1] run tag @s remove neg_x_neg_z_1
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_1] run tag @s remove pos_x_neg_z_1
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_1] run tag @s remove pos_x_pos_z_1
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_1] run tag @s remove neg_x_pos_z_1

# Detect
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=neg_z,distance=..1] run tp @s ~ ~ ~-0.35 180 5
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=pos_z,distance=..1] run tp @s ~ ~ ~0.35 0 5
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=pos_x,distance=..1] run tp @s ~0.35 ~ ~ -90 5
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=neg_x,distance=..1] run tp @s ~-0.35 ~ ~ 90 5

execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=neg_z,distance=..1] align x run tp @s ~0.5 ~ ~
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=pos_z,distance=..1] align x run tp @s ~0.5 ~ ~
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=pos_x,distance=..1] align z run tp @s ~ ~ ~0.5
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=neg_x,distance=..1] align z run tp @s ~ ~ ~0.5

execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=neg_x_neg_z,distance=..0.5] run tag @s add neg_x_neg_z_1 
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=pos_x_neg_z,distance=..0.5] run tag @s add pos_x_neg_z_1 
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=pos_x_pos_z,distance=..0.5] run tag @s add pos_x_pos_z_1 
execute as @e[tag=pathfinding,tag=follower,tag=!moving] at @s if entity @e[tag=pathfinding,tag=waypoint,tag=neg_x_pos_z,distance=..0.5] run tag @s add neg_x_pos_z_1 

execute as @e[tag=pathfinding,tag=follower,tag=neg_x_neg_z_1] run tag @s add moving
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_neg_z_1] run tag @s add moving
execute as @e[tag=pathfinding,tag=follower,tag=pos_x_pos_z_1] run tag @s add moving
execute as @e[tag=pathfinding,tag=follower,tag=neg_x_pos_z_1] run tag @s add moving