function pathfinding:options/steps_per_tick/1
function pathfinding:options
