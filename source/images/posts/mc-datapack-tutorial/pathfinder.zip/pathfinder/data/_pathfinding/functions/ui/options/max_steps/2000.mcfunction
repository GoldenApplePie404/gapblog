function pathfinding:options/max_steps/2000
function pathfinding:options
