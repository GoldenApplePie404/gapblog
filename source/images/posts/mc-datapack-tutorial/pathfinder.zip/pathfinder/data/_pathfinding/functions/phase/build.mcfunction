execute at @e[tag=pathfinding,tag=current] positioned ~1 ~ ~ if entity @e[tag=pathfinding,tag=done,tag=path,distance=..0.1] run summon minecraft:area_effect_cloud ~-1 ~ ~ {Tags:["pathfinding", "waypoint", "pos_x"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute at @e[tag=pathfinding,tag=current] positioned ~-1 ~ ~ if entity @e[tag=pathfinding,tag=done,tag=path,distance=..0.1] run summon minecraft:area_effect_cloud ~1 ~ ~ {Tags:["pathfinding", "waypoint", "neg_x"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute at @e[tag=pathfinding,tag=current] positioned ~ ~ ~1 if entity @e[tag=pathfinding,tag=done,tag=path,distance=..0.1] run summon minecraft:area_effect_cloud ~ ~ ~-1 {Tags:["pathfinding", "waypoint", "pos_z"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute at @e[tag=pathfinding,tag=current] positioned ~ ~ ~-1 if entity @e[tag=pathfinding,tag=done,tag=path,distance=..0.1] run summon minecraft:area_effect_cloud ~ ~ ~1 {Tags:["pathfinding", "waypoint", "neg_z"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute at @e[tag=pathfinding,tag=current] positioned ~1 ~ ~1 if entity @e[tag=pathfinding,tag=done,tag=path,distance=..0.1] run summon minecraft:area_effect_cloud ~-1 ~ ~-1 {Tags:["pathfinding", "waypoint", "pos_x_pos_z"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute at @e[tag=pathfinding,tag=current] positioned ~-1 ~ ~-1 if entity @e[tag=pathfinding,tag=done,tag=path,distance=..0.1] run summon minecraft:area_effect_cloud ~1 ~ ~1 {Tags:["pathfinding", "waypoint", "neg_x_neg_z"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute at @e[tag=pathfinding,tag=current] positioned ~1 ~ ~-1 if entity @e[tag=pathfinding,tag=done,tag=path,distance=..0.1] run summon minecraft:area_effect_cloud ~-1 ~ ~1 {Tags:["pathfinding", "waypoint", "pos_x_neg_z"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute at @e[tag=pathfinding,tag=current] positioned ~-1 ~ ~1 if entity @e[tag=pathfinding,tag=done,tag=path,distance=..0.1] run summon minecraft:area_effect_cloud ~1 ~ ~-1 {Tags:["pathfinding", "waypoint", "neg_x_pos_z"], Particle:"block air", Age:-2147483648, Duration: 2147483648}

execute as @e[tag=pathfinding,tag=current] run tag @s remove done

execute at @e[tag=pathfinding,tag=current] as @e[tag=pathfinding,tag=done,distance=1..1.1] run tag @s add next_current
execute unless entity @e[tag=pathfinding,tag=path,tag=done,tag=next_current] at @e[tag=pathfinding,tag=current] as @e[tag=pathfinding,tag=done,distance=1.4..1.5] run tag @s add next_current
tag @e[tag=pathfinding,tag=current] remove current
tag @e[tag=pathfinding,tag=next_current] add current
tag @e[tag=pathfinding,tag=next_current] remove next_current

# Count steps and check if step count is too high (tick)
execute if entity @e[tag=pathfinding,tag=done] unless data storage pathfinding:options {steps_per_tick: -1} run scoreboard players add @e[tag=pathfinding,tag=start] tick_steps 1
execute unless data storage pathfinding:options {steps_per_tick: -1} if score @e[tag=pathfinding,tag=start,limit=1] tick_steps >= @e[tag=pathfinding,tag=start,limit=1] steps_per_tick run data merge storage pathfinding:variables {stop_tick: 1b}
execute if data storage pathfinding:variables {stop_tick: 1b} run data merge storage pathfinding:variables {continue_at: "build"}

# Restart if not at end
execute if entity @e[tag=pathfinding,tag=done] unless data storage pathfinding:variables {stop_tick: 1b} run function _pathfinding:phase/build

# Start next phase if at end (and steps_per_tick is not -1)
execute unless data storage pathfinding:options {steps_per_tick: -1} unless entity @e[tag=pathfinding,tag=done] if data storage pathfinding:options {visual: 0b} if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:clear/path
execute unless data storage pathfinding:options {steps_per_tick: -1} unless entity @e[tag=pathfinding,tag=done] if data storage pathfinding:variables {stop_processing: 0b} if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:ui/finish
execute unless data storage pathfinding:options {steps_per_tick: -1} unless entity @e[tag=pathfinding,tag=done] if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:phase/cleanup