# Default Options
execute unless data storage pathfinding:options visual run data merge storage pathfinding:options {visual: 1b}
execute unless data storage pathfinding:options algorithm run data merge storage pathfinding:options {algorithm: "a_star_manhattan"}
execute unless data storage pathfinding:options diagonal run data merge storage pathfinding:options {diagonal: 1b}
execute unless data storage pathfinding:options max_steps run data merge storage pathfinding:options {max_steps: 1000}
execute unless data storage pathfinding:options steps_per_tick run data merge storage pathfinding:options {steps_per_tick: -1}
execute unless data storage pathfinding:options welcome_message run data merge storage pathfinding:options {welcome_message: 1b}

# Variables 
data merge storage pathfinding:variables {stop_processing: 0b}
data merge storage pathfinding:variables {stop_tick: 0b}
data merge storage pathfinding:variables {continue_at: ""}

# Show welcome message
execute if data storage pathfinding:options {welcome_message: 1b} run schedule function _pathfinding:ui/welcome 3s
