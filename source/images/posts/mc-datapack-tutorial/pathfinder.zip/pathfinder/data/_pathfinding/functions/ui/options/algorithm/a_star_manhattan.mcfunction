function pathfinding:options/algorithm/a_star_manhattan
function pathfinding:options
