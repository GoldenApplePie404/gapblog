kill @e[tag=pathfinding,tag=path]
