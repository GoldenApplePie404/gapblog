# Set x_value and z_value scores of new explore entities
execute as @e[tag=pathfinding,tag=new] store result score @s x_value run data get entity @s Pos[0]
execute as @e[tag=pathfinding,tag=new] store result score @s z_value run data get entity @s Pos[2]

# Set h_cost of new explore entities

# Set left and right side of the x operation
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side = @s x_value
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s right_side = @e[tag=pathfinding,tag=end,limit=1] x_value
# Run the x operation and store the value in the h_cost score
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side -= @s right_side
execute as @e[tag=pathfinding,tag=new] if score @s left_side matches ..0 run scoreboard players operation @s left_side *= @e[tag=pathfinding,tag=start] -1
execute if data storage pathfinding:options {algorithm: "a_star_euclidean"} as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side *= @s left_side
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s h_cost = @s left_side

# Set left and right side of the z operation
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side = @s z_value
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s right_side = @e[tag=pathfinding,tag=end,limit=1] z_value
# Run the z operation and add the value to the h_cost score
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side -= @s right_side
execute as @e[tag=pathfinding,tag=new] if score @s left_side matches ..0 run scoreboard players operation @s left_side *= @e[tag=pathfinding,tag=start] -1
execute if data storage pathfinding:options {algorithm: "a_star_euclidean"} as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side *= @s left_side
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s h_cost += @s left_side

# Square root the h-cost
execute if data storage pathfinding:options {algorithm: "a_star_euclidean"} as @e[tag=pathfinding,tag=new] run scoreboard players operation @s math_in = @s h_cost
execute if data storage pathfinding:options {algorithm: "a_star_euclidean"} as @e[tag=pathfinding,tag=new] run function math_pathfinding:sqrt
execute if data storage pathfinding:options {algorithm: "a_star_euclidean"} as @e[tag=pathfinding,tag=new] run scoreboard players operation @s h_cost = @s math_out

# Mulitplier for h-cost
execute if data storage pathfinding:options {algorithm: "a_star_manhattan"} as @e[tag=pathfinding,tag=new] run scoreboard players operation @s h_cost *= @e[tag=pathfinding,tag=start,limit=1] multi

# Set new_cost of new explore entities (and adjacent ones not tagged with done)
execute as @e[tag=pathfinding,tag=new] run scoreboard players set @s cost 999999999
execute at @e[tag=pathfinding,tag=current] as @e[tag=pathfinding,tag=!new,tag=!done,distance=1..1.1] run tag @s add straight
execute if data storage pathfinding:options {diagonal: 1b} at @e[tag=pathfinding,tag=current] as @e[tag=pathfinding,tag=!new,tag=!done,distance=1.4..1.5] run tag @s add diagonal
execute as @e[tag=pathfinding,tag=straight] run tag @s add old
execute as @e[tag=pathfinding,tag=diagonal] run tag @s add old
execute as @e[tag=pathfinding,tag=old] run tag @s add modify
execute as @e[tag=pathfinding,tag=new] run tag @s add modify
execute as @e[tag=pathfinding,tag=modify] run scoreboard players operation @s new_cost = @e[tag=pathfinding,tag=current,limit=1] cost
execute as @e[tag=pathfinding,tag=modify,tag=straight] run scoreboard players add @s new_cost 100
execute as @e[tag=pathfinding,tag=modify,tag=diagonal] run scoreboard players add @s new_cost 141

# Set cost of new explore entities and (adjacent ones) if new_cost is smaller than current
execute as @e[tag=pathfinding,tag=modify,tag=old] if score @s new_cost < @s cost run tag @s add updated
execute as @e[tag=pathfinding,tag=modify] if score @s new_cost < @s cost run scoreboard players operation @s cost = @s new_cost

# Update the position tags for explore entities tagged with updated
execute as @e[tag=pathfinding,tag=updated,tag=neg_x] run tag @s remove neg_x
execute as @e[tag=pathfinding,tag=updated,tag=pos_x] run tag @s remove pos_x
execute as @e[tag=pathfinding,tag=updated,tag=neg_z] run tag @s remove neg_z
execute as @e[tag=pathfinding,tag=updated,tag=pos_z] run tag @s remove pos_z
execute as @e[tag=pathfinding,tag=updated,tag=neg_x_neg_z] run tag @s remove neg_x_neg_z
execute as @e[tag=pathfinding,tag=updated,tag=pos_x_pos_z] run tag @s remove pos_x_pos_z
execute as @e[tag=pathfinding,tag=updated,tag=neg_x_pos_z] run tag @s remove neg_x_pos_z
execute as @e[tag=pathfinding,tag=updated,tag=pos_x_neg_z] run tag @s remove pos_x_neg_z
execute at @e[tag=pathfinding,tag=current] positioned ~-1 ~ ~ as @e[tag=pathfinding,tag=updated,distance=..0.1] run tag @s add pos_x
execute at @e[tag=pathfinding,tag=current] positioned ~1 ~ ~ as @e[tag=pathfinding,tag=updated,distance=..0.1] run tag @s add neg_x
execute at @e[tag=pathfinding,tag=current] positioned ~ ~ ~-1 as @e[tag=pathfinding,tag=updated,distance=..0.1] run tag @s add pos_z
execute at @e[tag=pathfinding,tag=current] positioned ~ ~ ~1 as @e[tag=pathfinding,tag=updated,distance=..0.1] run tag @s add neg_z
execute at @e[tag=pathfinding,tag=current] positioned ~-1 ~ ~-1 as @e[tag=pathfinding,tag=updated,distance=..0.1] run tag @s add pos_x_pos_z
execute at @e[tag=pathfinding,tag=current] positioned ~1 ~ ~1 as @e[tag=pathfinding,tag=updated,distance=..0.1] run tag @s add neg_x_neg_z
execute at @e[tag=pathfinding,tag=current] positioned ~-1 ~ ~1 as @e[tag=pathfinding,tag=updated,distance=..0.1] run tag @s add pos_x_neg_z
execute at @e[tag=pathfinding,tag=current] positioned ~1 ~ ~-1 as @e[tag=pathfinding,tag=updated,distance=..0.1] run tag @s add neg_x_pos_z

# Set the f_cost by adding cost and h_cost (to new and updated ones)
execute as @e[tag=pathfinding,tag=modify] run scoreboard players operation @s f_cost = @s cost
execute as @e[tag=pathfinding,tag=modify] run scoreboard players operation @s f_cost += @s h_cost