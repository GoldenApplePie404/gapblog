function pathfinding:options/steps_per_tick/all
function pathfinding:options
