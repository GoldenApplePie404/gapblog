# Summon new explore entities next to current (if block is free)
execute if data storage pathfinding:options {visual: 0b} run function _pathfinding:blocks/summon_neighbors/straight_visual_false
execute if data storage pathfinding:options {visual: 0b} if data storage pathfinding:options {diagonal: 1b} run function _pathfinding:blocks/summon_neighbors/diagonal_visual_false
execute if data storage pathfinding:options {visual: 1b} run function _pathfinding:blocks/summon_neighbors/straight_visual_true
execute if data storage pathfinding:options {visual: 1b} if data storage pathfinding:options {diagonal: 1b} run function _pathfinding:blocks/summon_neighbors/diagonal_visual_true

# Calculate costs based on the used algorithm
execute if data storage pathfinding:options {algorithm: "a_star_manhattan"} run function _pathfinding:blocks/calc_cost/a_star
execute if data storage pathfinding:options {algorithm: "a_star_euclidean"} run function _pathfinding:blocks/calc_cost/a_star
execute if data storage pathfinding:options {algorithm: "dijkstra"} run function _pathfinding:blocks/calc_cost/dijkstra
execute if data storage pathfinding:options {algorithm: "best_first"} run function _pathfinding:blocks/calc_cost/best_first

# Remove the modify, new, old, straight, diagonal and updated tags
execute as @e[tag=pathfinding,tag=modify] run tag @s remove modify
execute as @e[tag=pathfinding,tag=new] run tag @s remove new
execute as @e[tag=pathfinding,tag=old] run tag @s remove old
execute as @e[tag=pathfinding,tag=straight] run tag @s remove straight
execute as @e[tag=pathfinding,tag=diagonal] run tag @s remove diagonal
execute as @e[tag=pathfinding,tag=updated] run tag @s remove updated

# Remove the current and add the done tag
tag @e[tag=pathfinding,tag=current] add done
tag @e[tag=pathfinding,tag=current] remove current

# Select the new current based on the used algorithm
execute if data storage pathfinding:options {algorithm: "a_star_manhattan"} run function _pathfinding:blocks/select_current/a_star
execute if data storage pathfinding:options {algorithm: "a_star_euclidean"} run function _pathfinding:blocks/select_current/a_star
execute if data storage pathfinding:options {algorithm: "dijkstra"} run function _pathfinding:blocks/select_current/dijkstra
execute if data storage pathfinding:options {algorithm: "best_first"} run function _pathfinding:blocks/select_current/best_first

# Tag the current with done if we're at the end
execute as @e[tag=pathfinding,tag=current] at @s if entity @e[tag=pathfinding,tag=end,distance=..0.1] run tag @s add done

# Check if there is no path available
execute unless entity @e[tag=pathfinding,tag=current] run data merge storage pathfinding:variables {stop_processing: 1b}
execute unless entity @e[tag=pathfinding,tag=current] run tellraw @a[scores={finder=1}] ["",{"text":"完成","color":"dark_green","bold": true},{"text":"\n寻路算法运行完毕，共走了 ","color": "light_purple"},{"score":{"name":"@e[tag=pathfinding,tag=start]","objective":"total_steps"},"color": "dark_purple","underlined": true},{"text":" 步!","color": "light_purple"},{"text": "\n未发现可用的路线!","color": "red","bold": true}]

# Count steps and check if step count is too high (total)
execute if data storage pathfinding:variables {stop_processing: 0b} run scoreboard players add @e[tag=pathfinding,tag=start] total_steps 1
execute unless data storage pathfinding:options {max_steps: -1} if score @e[tag=pathfinding,tag=start,limit=1] total_steps >= @e[tag=pathfinding,tag=start,limit=1] max_steps run data merge storage pathfinding:variables {stop_processing: 1b}
execute unless data storage pathfinding:options {max_steps: -1} if score @e[tag=pathfinding,tag=start,limit=1] total_steps >= @e[tag=pathfinding,tag=start,limit=1] max_steps run tellraw @a[scores={finder=1}] ["",{"text":"出错","color":"dark_red"},{"text":"\n已终止寻路, 因为寻路步数超过所设置的最大值!\n 请在设置菜单里重新设置最大步数!","color": "red"}]

# Count steps and check if step count is too high (tick)
execute if data storage pathfinding:variables {stop_processing: 0b} unless entity @e[tag=pathfinding,tag=current,tag=done] unless data storage pathfinding:options {steps_per_tick: -1} run scoreboard players add @e[tag=pathfinding,tag=start] tick_steps 1
execute unless data storage pathfinding:options {steps_per_tick: -1} if score @e[tag=pathfinding,tag=start,limit=1] tick_steps >= @e[tag=pathfinding,tag=start,limit=1] steps_per_tick run data merge storage pathfinding:variables {stop_tick: 1b}
execute if data storage pathfinding:variables {stop_tick: 1b} run data merge storage pathfinding:variables {continue_at: "explore"}

# Restart step if not at end and if max_steps allows it
execute unless entity @e[tag=pathfinding,tag=current,tag=done] unless data storage pathfinding:variables {stop_processing: 1b} unless data storage pathfinding:variables {stop_tick: 1b} run function _pathfinding:phase/explore

# Start next phase if at end (and steps_per_tick is not -1)
execute unless data storage pathfinding:options {steps_per_tick: -1} if entity @e[tag=pathfinding,tag=current,tag=done] if data storage pathfinding:variables {stop_processing: 0b} if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:phase/backtrack

# Clear explore if there is no path availabe and steps_per_tick is not -1
execute unless data storage pathfinding:options {steps_per_tick: -1} unless entity @e[tag=pathfinding,tag=current,tag=done] if data storage pathfinding:variables {stop_processing: 1b} run function _pathfinding:clear/explore
execute unless data storage pathfinding:options {steps_per_tick: -1} unless entity @e[tag=pathfinding,tag=current,tag=done] if data storage pathfinding:variables {stop_processing: 1b} run function _pathfinding:phase/cleanup