kill @e[tag=pathfinding,tag=explore,tag=!path]
