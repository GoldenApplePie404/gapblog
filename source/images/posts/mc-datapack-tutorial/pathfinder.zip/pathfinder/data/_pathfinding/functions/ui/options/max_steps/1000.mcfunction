function pathfinding:options/max_steps/1000
function pathfinding:options
