function pathfinding:menu
function pathfinding:run