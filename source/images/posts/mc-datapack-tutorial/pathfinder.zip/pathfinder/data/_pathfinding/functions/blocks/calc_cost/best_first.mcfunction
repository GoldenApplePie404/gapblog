# Set x_value and z_value scores of new armor_stands to x and z coords
execute as @e[tag=pathfinding,tag=new] store result score @s x_value run data get entity @s Pos[0]
execute as @e[tag=pathfinding,tag=new] store result score @s z_value run data get entity @s Pos[2]

# Set h_cost of new armor_stands

# Set left and right side of the x operation
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side = @s x_value
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s right_side = @e[tag=pathfinding,tag=end,limit=1] x_value
# Run the x operation and store the value in the h_cost score
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side -= @s right_side
execute as @e[tag=pathfinding,tag=new] if score @s left_side matches ..0 run scoreboard players operation @s left_side *= @e[tag=pathfinding,tag=start] -1
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s h_cost = @s left_side

# Set left and right side of the z operation
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side = @s z_value
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s right_side = @e[tag=pathfinding,tag=end,limit=1] z_value
# Run the z operation and add the value to the h_cost score
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s left_side -= @s right_side
execute as @e[tag=pathfinding,tag=new] if score @s left_side matches ..0 run scoreboard players operation @s left_side *= @e[tag=pathfinding,tag=start] -1
execute as @e[tag=pathfinding,tag=new] run scoreboard players operation @s h_cost += @s left_side

# Mulitplier for h-cost
#execute if data storage pathfinding:options {algorithm: "a_star_manhattan"} as @e[tag=pathfinding,tag=new] run scoreboard players operation @s h_cost *= @e[tag=pathfinding,tag=start,limit=1] multi
