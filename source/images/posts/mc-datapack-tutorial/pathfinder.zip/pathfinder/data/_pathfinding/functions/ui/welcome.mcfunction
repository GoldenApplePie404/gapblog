tellraw @a [{"text":"\n------------","underlined":false,"color":"yellow","bold": true,"strikethrough": true}]
tellraw @a [{"text":"寻路模块加载完毕","underlined":false,"color":"aqua","bold": true}]
tellraw @a [{"text":"【打开菜单】","underlined":false,"color":"gold","clickEvent":{"action":"run_command","value":"/function pathfinding:menu"}}]
tellraw @a [{"text":"------------","underlined":false,"color":"yellow","bold": true,"strikethrough": true}]