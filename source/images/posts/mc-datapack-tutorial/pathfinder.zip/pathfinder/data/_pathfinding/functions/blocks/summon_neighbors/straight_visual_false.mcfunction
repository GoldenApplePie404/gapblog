execute as @e[tag=pathfinding,tag=current] at @s positioned ~1 ~ ~ if block ~ ~ ~ minecraft:air unless entity @e[tag=pathfinding,tag=explore,distance=..0.1] run summon minecraft:area_effect_cloud ~ ~ ~ {Tags: ["pathfinding", "explore", "new", "straight", "neg_x"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute as @e[tag=pathfinding,tag=current] at @s positioned ~-1 ~ ~ if block ~ ~ ~ minecraft:air unless entity @e[tag=pathfinding,tag=explore,distance=..0.1] run summon minecraft:area_effect_cloud ~ ~ ~ {Tags: ["pathfinding", "explore", "new", "straight","pos_x"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute as @e[tag=pathfinding,tag=current] at @s positioned ~ ~ ~1 if block ~ ~ ~ minecraft:air unless entity @e[tag=pathfinding,tag=explore,distance=..0.1] run summon minecraft:area_effect_cloud ~ ~ ~ {Tags: ["pathfinding", "explore", "new", "straight","neg_z"], Particle:"block air", Age:-2147483648, Duration: 2147483648}
execute as @e[tag=pathfinding,tag=current] at @s positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:air unless entity @e[tag=pathfinding,tag=explore,distance=..0.1] run summon minecraft:area_effect_cloud ~ ~ ~ {Tags: ["pathfinding", "explore", "new", "straight","pos_z"], Particle:"block air", Age:-2147483648, Duration: 2147483648}



