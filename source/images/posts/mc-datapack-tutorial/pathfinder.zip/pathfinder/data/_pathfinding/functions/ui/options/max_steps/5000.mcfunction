function pathfinding:options/max_steps/5000
function pathfinding:options
