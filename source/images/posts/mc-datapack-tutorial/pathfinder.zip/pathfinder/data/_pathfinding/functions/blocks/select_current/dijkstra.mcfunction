# Find the minimal cost of all armor_stands not tagged with done and set it to the start
scoreboard players set @e[tag=pathfinding,tag=start,limit=1] cost 999999999
execute as @e[tag=pathfinding,tag=explore,tag=!done] run scoreboard players operation @e[tag=pathfinding,tag=start,limit=1] cost < @s cost

# Select new current
execute as @e[tag=pathfinding,tag=explore,tag=!done] if score @s cost = @e[tag=pathfinding,tag=start,limit=1] cost run tag @s add next_current
execute as @e[tag=pathfinding,tag=explore,tag=next_current,limit=1,sort=random] run tag @s add current
execute as @e[tag=pathfinding,tag=explore,tag=next_current] run tag @s remove next_current