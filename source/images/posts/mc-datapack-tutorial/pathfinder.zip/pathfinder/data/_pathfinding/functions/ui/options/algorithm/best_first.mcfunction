function pathfinding:options/algorithm/best_first
function pathfinding:options
