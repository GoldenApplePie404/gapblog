function _pathfinding:clear/explore
function _pathfinding:clear/way
function _pathfinding:clear/path