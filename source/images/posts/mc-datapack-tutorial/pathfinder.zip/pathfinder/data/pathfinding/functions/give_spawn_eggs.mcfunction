clear @p minecraft:blaze_spawn_egg{display:{Name:"{\"text\":\"Start\"}"}, EntityTag:{id:"minecraft:armor_stand", Tags:["pathfinding", "start"], ShowArms:1b, NoGravity:1b,CustomName:"{\"text\":\"Start\"}",CustomNameVisible:1b,DisabledSlots:2039583}}
clear @p minecraft:blaze_spawn_egg{display:{Name:"{\"text\":\"End\"}"}, EntityTag:{id:"minecraft:armor_stand", Tags:["pathfinding", "end"], ShowArms:1b, NoGravity:1b,CustomName:"{\"text\":\"End\"}",CustomNameVisible:1b,DisabledSlots:2039583}}
clear @p minecraft:chicken_spawn_egg{display:{Name:"{\"text\":\"Pathfinding Chicken\"}"},EntityTag:{id:"minecraft:chicken", Tags:["pathfinding", "follower"], Invulnerable:1b, NoAI:1b, Silent:1b }}



give @p minecraft:blaze_spawn_egg{display:{Name:"{\"text\":\"Start\"}"}, EntityTag:{id:"minecraft:armor_stand", Tags:["pathfinding", "start"], ShowArms:1b, NoGravity:1b,CustomName:"{\"text\":\"Start\"}",CustomNameVisible:1b,DisabledSlots:2039583}} 1
give @p minecraft:blaze_spawn_egg{display:{Name:"{\"text\":\"End\"}"}, EntityTag:{id:"minecraft:armor_stand", Tags:["pathfinding", "end"], ShowArms:1b, NoGravity:1b,CustomName:"{\"text\":\"End\"}",CustomNameVisible:1b,DisabledSlots:2039583}} 1
give @p minecraft:chicken_spawn_egg{display:{Name:"{\"text\":\"Pathfinding Chicken\"}"},EntityTag:{id:"minecraft:chicken", Tags:["pathfinding", "follower"], Invulnerable:1b, NoAI:1b, Silent:1b }} 1