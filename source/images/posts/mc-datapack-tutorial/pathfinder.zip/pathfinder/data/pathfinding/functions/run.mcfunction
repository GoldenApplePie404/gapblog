function _pathfinding:phase/check

function _pathfinding:clear/explore
function _pathfinding:clear/way
function _pathfinding:clear/path
execute if data storage pathfinding:variables {stop_processing: 0b} run function _pathfinding:phase/start

execute if data storage pathfinding:variables {stop_processing: 0b} run function _pathfinding:phase/explore

execute if data storage pathfinding:variables {stop_processing: 0b} if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:phase/backtrack
execute if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:clear/explore

execute if data storage pathfinding:variables {stop_processing: 0b} if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:phase/build
execute if data storage pathfinding:options {visual: 0b} if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:clear/path

execute if data storage pathfinding:variables {stop_processing: 0b} if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:ui/finish

execute if data storage pathfinding:variables {stop_tick: 0b} run function _pathfinding:phase/cleanup