# Clear all entities
function _pathfinding:clear/all

# Run the cleanup
function _pathfinding:phase/cleanup

# Remove the option storage
data remove storage pathfinding:options visual
data remove storage pathfinding:options algorithm
data remove storage pathfinding:options diagonal
data remove storage pathfinding:options max_steps
data remove storage pathfinding:options steps_per_tick
data remove storage pathfinding:options welcome_message

# Remove the variable storage
data remove storage pathfinding:variables stop_processing
data remove storage pathfinding:variables stop_tick
data remove storage pathfinding:variables continue_at